<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login — Pasture of Life International</title>
    <link rel="icon" type="image/png" href="https://www.pastureoflife.org/assets/images/logo.png">
    <link rel="shortcut icon" href="https://www.pastureoflife.org/assets/images/logo.png">
        <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-P5TKS5TW');</script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { background: linear-gradient(135deg, #1a3a5c 0%, #2e7d32 100%); min-height: 100vh; display: flex; align-items: center; }
        .login-card { border: none; border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
        .login-header { background: linear-gradient(135deg, #1a3a5c, #2e7d32); border-radius: 16px 16px 0 0; padding: 2rem; text-align: center; }
        .form-control:focus { border-color: #2e7d32; box-shadow: 0 0 0 .2rem rgba(46,125,50,.25); }
        .btn-login { background: linear-gradient(135deg, #1a3a5c, #2e7d32); border: none; padding: .75rem; font-size: 1.05rem; }
        .btn-login:hover { opacity: .9; }
    </style>
</head>
<body>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P5TKS5TW" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5 col-lg-4">
            <div class="card login-card">
                <div class="login-header text-white">
                    <img src="https://www.pastureoflife.org/assets/images/logo.png" alt="Pasture of Life International" style="height:60px;margin-bottom:.75rem">
                    <h4 class="mb-0 fw-bold">Pasture of Life International</h4>
                    <small class="opacity-75">Admin Portal</small>
                </div>
                <div class="card-body p-4">
                    
                    <form method="POST" novalidate>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Email Address</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                                <input type="email" name="email" class="form-control"
                                    value=""
                                    placeholder="Enter your email" required autofocus
                                    autocomplete="username">
                            </div>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Password</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="bi bi-key"></i></span>
                                <input type="password" name="password" id="password"
                                    class="form-control" placeholder="••••••••" required
                                    autocomplete="current-password">
                                <button class="btn btn-outline-secondary" type="button"
                                    onclick="var p=document.getElementById('password'),i=document.getElementById('pwd-icon');p.type=p.type==='password'?'text':'password';i.className=p.type==='text'?'bi bi-eye-slash':'bi bi-eye'">
                                    <i class="bi bi-eye" id="pwd-icon"></i>
                                </button>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-login btn-primary w-100 text-white fw-bold rounded-pill">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
                        </button>
                    </form>
                    <p class="text-center text-muted mt-3 mb-0 small">
                        <a href="https://www.pastureoflife.org" class="text-decoration-none">
                            <i class="bi bi-house-door"></i> Back to Website
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
