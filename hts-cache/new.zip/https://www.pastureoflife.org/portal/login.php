<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Login — Pasture of Life International</title>
    <link rel="icon" type="image/png" href="https://www.pastureoflife.org/assets/images/logo.png">
    <link rel="shortcut icon" href="https://www.pastureoflife.org/assets/images/logo.png">
        <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-P5TKS5TW');</script>
    <!-- End Google Tag Manager -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { background: linear-gradient(135deg, #1a3a5c 0%, #2e7d32 100%); min-height: 100vh; display: flex; align-items: center; }
        .login-card { border-radius: 16px; box-shadow: 0 12px 40px rgba(0,0,0,.25); }
    </style>
</head>
<body>
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P5TKS5TW" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-sm-10 col-md-7 col-lg-5">
            <div class="text-center mb-4">
                <img src="https://www.pastureoflife.org/assets/images/logo.png" alt="Pasture of Life International" style="height:70px">
                <h4 class="text-white fw-bold mt-3">Pasture of Life International</h4>
                <p class="text-white-50">Member Portal</p>
            </div>
            <div class="card login-card p-4">
                <h5 class="fw-bold mb-1 text-center">Welcome Back</h5>
                <p class="text-muted small text-center mb-4">Sign in to manage your profile</p>
                                <form method="POST">
                                        <div class="mb-3">
                        <label class="form-label">Phone Number</label>
                        <input type="tel" name="phone" class="form-control"
                               value=""
                               placeholder="e.g. 08012345678" required autofocus
                               autocomplete="username">
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control"
                               required autocomplete="current-password">
                    </div>
                    <button type="submit" class="btn w-100 text-white fw-bold py-2"
                        style="background:linear-gradient(135deg,#1a3a5c,#2e7d32)">
                        <i class="bi bi-box-arrow-in-right me-2"></i>Sign In
                    </button>
                </form>
                <hr class="my-3">
                <p class="text-center small text-muted mb-0">
                    Don't have access? Contact your church admin to set up your account.
                </p>
            </div>
            <div class="text-center mt-3">
                <a href="https://www.pastureoflife.org" class="text-white-50 small">
                    <i class="bi bi-arrow-left me-1"></i>Back to Website
                </a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
